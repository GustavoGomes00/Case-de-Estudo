from random import randint


def escolher_dificuldade() -> tuple:
    print("\nEscolha a dificuldade:")
    print("  1 - Fácil   (1 a 50,  10 tentativas)")
    print("  2 - Médio   (1 a 100,  7 tentativas)")
    print("  3 - Difícil (1 a 200,  5 tentativas)")

    opcoes = {"1": (50, 10), "2": (100, 7), "3": (200, 5)}

    while True:
        escolha = input("\nOpção: ").strip()
        if escolha in opcoes:
            return opcoes[escolha]
        print("Opção inválida! Digite 1, 2 ou 3.")


def dar_dica(tentativa: int, numero_secreto: int) -> None:
    diferenca = abs(tentativa - numero_secreto)
    if diferenca <= 5:
        print("Muito quente! Quase lá!")
    elif diferenca <= 15:
        print("Quente! Está chegando perto.")
    elif diferenca <= 30:
        print("Morno... ainda longe.")
    else:
        print("Frio! Bem longe do número.")

    if tentativa < numero_secreto:
        print("⬆O número secreto é MAIOR.\n")
    else:
        print("⬇O número secreto é MENOR.\n")


def jogar() -> None:
    print("=" * 45)
    print("JOGO DE ADIVINHAÇÃO")
    print("=" * 45)

    limite, max_tentativas = escolher_dificuldade()
    numero_secreto = randint(1, limite)
    tentativas_usadas = 0

    print(f"\nEscolhi um número entre 1 e {limite}.")
    print(f"Você tem {max_tentativas} tentativas. Boa sorte!\n")

    while tentativas_usadas < max_tentativas:
        restantes = max_tentativas - tentativas_usadas
        try:
            tentativa = int(input(f"[{restantes} tentativa(s)] Seu palpite: "))
        except ValueError:
            print("Digite apenas números inteiros!\n")
            continue

        if tentativa < 1 or tentativa > limite:
            print(f"Digite um número entre 1 e {limite}!\n")
            continue

        tentativas_usadas += 1

        if tentativa == numero_secreto:
            print(f"\n Parabéns! Você acertou!")
            print(f"O número era {numero_secreto}.")
            print(f"Você usou {tentativas_usadas} de {max_tentativas} tentativas.")
            break

        dar_dica(tentativa, numero_secreto)

    else:
        print(f"\n Suas tentativas acabaram!")
        print(f"O número secreto era: {numero_secreto}")


def main() -> None:
    while True:
        jogar()
        print("\n" + "-" * 45)
        jogar_novamente = input("Jogar novamente? (s/n): ").strip().lower()
        if jogar_novamente != "s":
            print("\n Obrigado por jogar! Até logo! ")
            break


if __name__ == "__main__":
    main()