def calcular_imc(peso: float, altura: float) -> float:
    return peso / (altura ** 2)


def classificar_imc(imc: float) -> str:
    if imc < 18.5:
        return "Abaixo do peso"
    elif imc < 25.0:
        return "Peso normal"
    elif imc < 30.0:
        return "Sobrepeso"
    elif imc < 35.0:
        return "Obesidade grau I"
    elif imc < 40.0:
        return "Obesidade grau II"
    else:
        return "Obesidade grau III"


def exibir_relatorio(nome: str, peso: float, altura: float, imc: float, classificacao: str) -> None:
    print("\n" + "=" * 40)
    print("       RESULTADO DO IMC")
    print("=" * 40)
    print(f"  Nome          : {nome}")
    print(f"  Peso          : {peso} kg")
    print(f"  Altura        : {altura} m")
    print(f"  IMC           : {imc:.2f}")
    print(f"  Classificação : {classificacao}")
    print("=" * 40)


def main():
    print("=" * 40)
    print("    CALCULADORA DE IMC")
    print("=" * 40)

    nome = input("\nSeu nome: ").strip()

    while True:
        try:
            peso = float(input("Peso (kg): "))
            if peso <= 0:
                print("Peso inválido! Digite um valor positivo.")
                continue
            break
        except ValueError:
            print("Entrada inválida! Digite um número.")

    while True:
        try:
            altura = float(input("Altura (m): "))
            if altura <= 0:
                print("Altura inválida! Digite um valor positivo.")
                continue
            break
        except ValueError:
            print("Entrada inválida! Digite um número.")

    imc = calcular_imc(peso, altura)
    classificacao = classificar_imc(imc)
    exibir_relatorio(nome, peso, altura, imc, classificacao)


if __name__ == "__main__":
    main()